import './App.css'
import Ejercicio1 from "./ejercicio1.jsx";
import Ejercicio2 from "./ejercicio2.jsx";
import Ejercicio3 from "./ejercicio3.jsx";

function App() {

  return (
    <Ejercicio3/>
  )
}

export default App
