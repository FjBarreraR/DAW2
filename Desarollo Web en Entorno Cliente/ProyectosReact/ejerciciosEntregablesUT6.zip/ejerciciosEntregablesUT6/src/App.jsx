import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ejercicio1 from "./Ejercicio1.jsx";
import Ejercicio1 from "./Ejercicio1.jsx";
import Ejercicio2 from "./Ejercicio2.jsx";
import Ejercicio3 from "./Ejercicio3.jsx";
import Ejercicio4 from "./Ejercicio4.jsx";
import TeamApp from "./Ejercicio5/TeamApp.jsx";

function App() {
  const [count, setCount] = useState(0)

  return (
      <TeamApp></TeamApp>
  )
}

export default App
